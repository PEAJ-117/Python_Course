"""Annual Investment"""

import math

# initial capital = c
# annual interest = i
# years = y
# CF = C0 x (1+i)^t

c = int(input("Inversion inicial: $ "))
i = int(input("Interes anual: "))
y = int(input("Años: "))

ix = i / 10
cf = (c)*(math.pow((1+ix), y))
cf = int(cf)

res = f"""
Inversion inicial: $ {c} .00
Interes anual: {i}% = {ix}
Años: {y}
Tu ganancia es: $ {cf} .00
"""

print(res)
