# import math

# Display in console
print("Hola Mundo!")
print("____________________")

# Save word and display
word = "Hola Mundo!"
print(word)
print("____________________")

# Request data and display it
name = input("Nombre: ")
print(f'!Hola {name}!')
print("____________________")

# Arithmetic
ar = ((3+2)/(2*5))**2
# ar2 = math.pow(ar, 2)
print(ar)
print("____________________")

# Arithmetic 2
hrs = int(input("Horas trabajadas: "))  # float
cost = int(input("Pago/HRS: "))  # float
salary = hrs * cost
print("Pago correspondiente: ", salary)

# Arithmetic 3
nn1 = int(input("Ingresa un numero entero: "))
addy = nn1 * (nn1 + 1) / 2
msj = f"""
La suma de los {nn1} primeros enteros, es: {addy}
"""
print(msj)
print("____________________")

# Body Mass Index (IMC) where IMC = KG/H**2
print("Calcula tu IMC")
kg = float(input("Ingrese su peso (kg): "))  # insert decimal numbers
h = float(input("Ingrese su altura (mts): "))
imc = int(kg/h**2)  # transform to integer result
print(f'Tu IMC es: {imc}')
print("____________________")

# Division
n = float(input("Introduce el numero a dividir: "))
m = float(input("Intoduce el divisor: "))
div = int(n/m)
res = n % m
print(f'Dividir {n} entre {m}, resulta: {div} y sobra: {res}')
print("____________________")

# Annual Investments
#
