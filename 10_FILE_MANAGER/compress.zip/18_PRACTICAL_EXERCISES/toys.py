# weights
clown = 112/1000
doll = 75/1000

# how many?
amount_C = 23
amount_D = 50

c = clown*amount_C
d = doll*amount_D
total = c + d

print(f"Peso total del paquete: {int(total)} kg")
