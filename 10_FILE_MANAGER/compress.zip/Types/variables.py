"""Learning to printing function"""

#Las variables
#Formatos recomendados: n1, name_load, nameLoad_redBatch, NAME_1

nombre_curso = "Ultimate Python"
nombre1 = "Hola"
NOMBRE_CURSO = "Mundo"

print(nombre_curso, nombre1, NOMBRE_CURSO) #Impresion de variables

alumnos = 5000   #Integer: Entero
puntaje = 9.9    #Float: Decimal
publicado = True #Bool: True / False
