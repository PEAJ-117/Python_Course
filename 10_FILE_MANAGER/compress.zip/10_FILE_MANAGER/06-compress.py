from pathlib import Path
from zipfile import ZipFile

with ZipFile("10_FILE_MANAGER/compress.zip", "w") as zip:
    for path in Path().rglob("*.*"):
        print(path)
        if str(path) != "10_FILE_MANAGER/compress.zip":
            zip.write(path)
